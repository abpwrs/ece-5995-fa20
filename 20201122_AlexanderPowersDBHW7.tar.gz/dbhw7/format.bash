#!/usr/bin/env bash
# Author: "alexander"
# Date: 20201121

black hw7.py
isort -rc hw7.py
